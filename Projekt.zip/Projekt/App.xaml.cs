﻿using System.Windows;

namespace Projekt;
public partial class App : Application
{
}
