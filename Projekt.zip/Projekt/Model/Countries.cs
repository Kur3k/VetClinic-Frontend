﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt.Model;

public static class Countries
{
    public static List<string> ListCountries = [
        "Albania", "Andorra", "Armenia", "Austria", "Azerbaijan", "Belarus",             
        "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Cyprus",            
        "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Georgia",             
        "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Kazakhstan",             
        "Kosovo", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta",             
        "Moldova", "Monaco", "Montenegro", "Netherlands", "North Macedonia",             
        "Norway", "Poland", "Portugal", "Romania", "Russia", "San Marino",             
        "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland",             
        "Turkey", "Ukraine", "United Kingdom", "Vatican City"
    ];
}
